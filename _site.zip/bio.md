Marco Piccirilli EE Ph.D. with research interests in machine learning, computer vision, is currently working
at the center for innovation, Heart and Vascular Institute West Virginia University.
He obtained a "laurea" degree in Telecommunication engineering from University of Padua (ITALY).
